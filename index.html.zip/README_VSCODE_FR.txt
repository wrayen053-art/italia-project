ITALIA — PROJET HTML / CSS / JAVASCRIPT POUR VISUAL STUDIO CODE

Le design et le contenu du site immersif précédent sont conservés.
La page d’ouverture présente maintenant les quatre membres de l’équipe :
- Mohammed Rayen Wesleti
- Mohammed Ben Ataya
- Aziz Ammar
- Hamadi Baraket

OUVRIR LE PROJET DANS VS CODE
1. Décompressez le dossier ITALIA_VSCode_Project.
2. Ouvrez Visual Studio Code.
3. Cliquez sur File > Open Folder et choisissez ce dossier.
4. Installez l’extension « Live Server » (Ritwick Dey) si elle n’est pas déjà installée.
5. Ouvrez index.html, puis cliquez sur « Go Live » en bas à droite.

POUR QUE LES TÉLÉPHONES PUISSENT SCANNER LE QR CODE
1. Connectez l’ordinateur et les téléphones au même réseau Wi-Fi.
2. Sur Windows, ouvrez CMD et tapez : ipconfig
3. Repérez « Adresse IPv4 » de la carte Wi-Fi (exemple : 192.168.1.25).
4. Sur l’ordinateur, ouvrez le site avec http://VOTRE-IP:5500 (exemple : http://192.168.1.25:5500).
   Important : utilisez cette adresse réseau, et non localhost.
5. Cliquez sur QR Code dans le menu. Le QR affiché correspondra à l’adresse réseau ouverte.
6. Les élèves scannent le code avec leurs téléphones.

Si Windows demande une autorisation pare-feu, autorisez Live Server sur les réseaux privés.
Gardez VS Code et Live Server ouverts pendant la présentation.

TECHNOLOGIES : HTML5, CSS3 et JavaScript. Aucun Python, aucune installation de serveur Python.
Les images, polices et la bibliothèque QR sont chargées depuis Internet.
Le quiz et le vote sont indépendants sur chaque appareil (pas de vote collectif synchronisé).
