@echo off
setlocal
chcp 65001 >nul
title ITALIA - Ouvrir le site et creer le QR Code
cd /d "%~dp0"

set "PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if not exist "%PS%" set "PS=%SystemRoot%\SysWOW64\WindowsPowerShell\v1.0\powershell.exe"
if not exist "%PS%" (
  echo PowerShell Windows est introuvable sur cet ordinateur.
  echo Contactez-moi avec une photo de cette fenetre.
  pause
  exit /b 1
)

echo.
echo  ================================================
echo       ITALIA - ACCES POUR TOUTE LA CLASSE
echo  ================================================
echo.
echo  Le site original est conserve.
echo  Preparation du serveur local et du lien public temporaire...
echo.

if not exist "cloudflared.exe" (
  echo Telechargement de Cloudflare Tunnel...
  "%PS%" -NoProfile -ExecutionPolicy Bypass -Command "try { Invoke-WebRequest -Uri 'https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-windows-amd64.exe' -OutFile 'cloudflared.exe' -UseBasicParsing } catch { Write-Host $_.Exception.Message; exit 1 }"
  if errorlevel 1 (
    echo.
    echo Echec du telechargement. Verifiez la connexion Internet.
    pause
    exit /b 1
  )
)

echo Demarrage du serveur du site...
start "ITALIA - Serveur local" "%PS%" -NoProfile -ExecutionPolicy Bypass -File "%~dp0serveur_local.ps1"
timeout /t 3 /nobreak >nul

echo Demarrage du lien Internet temporaire...
echo Patientez quelques secondes...
if exist "tunnel.log" del "tunnel.log"
start "ITALIA - Lien public (ne pas fermer)" /min cmd /c ""%~dp0cloudflared.exe" tunnel --url http://127.0.0.1:5500 --no-autoupdate > "%~dp0tunnel.log" 2>&1"

set "TUNNEL_URL="
for /l %%i in (1,1,60) do (
  if not defined TUNNEL_URL (
    for /f "usebackq tokens=*" %%u in (`"%PS%" -NoProfile -Command "$m = Select-String -Path '%~dp0tunnel.log' -Pattern 'https://[a-z0-9-]+\.trycloudflare\.com' -AllMatches -ErrorAction SilentlyContinue | Select-Object -First 1; if ($m) { $m.Matches.Value }"`) do set "TUNNEL_URL=%%u"
  )
  if defined TUNNEL_URL goto READY
  timeout /t 2 /nobreak >nul
)

echo.
echo Impossible d'obtenir le lien automatiquement.
echo Ouvrez tunnel.log et envoyez-moi une photo du message.
pause
exit /b 1

:READY
echo.
echo  ================================================
echo  PRET ! LIEN POUR LES ELEVES :
echo  %TUNNEL_URL%
echo  ================================================
echo.
echo Ouverture de la page avec le QR Code...
"%PS%" -NoProfile -ExecutionPolicy Bypass -Command "$u='%TUNNEL_URL%'; $e=[uri]::EscapeDataString($u); $html='<!doctype html><html lang=fr><meta charset=utf-8><meta name=viewport content="width=device-width,initial-scale=1"><title>ITALIA - QR</title><body style="font-family:Arial;text-align:center;background:#f7faf8;color:#17251e;padding:25px"><h1>ITALIA</h1><h2>Scannez pour ouvrir le projet</h2><img style="width:min(82vw,430px);height:auto;background:white;padding:12px" src="https://api.qrserver.com/v1/create-qr-code/?size=600x600&margin=15&data='+$e+'"><p style="font-size:20px;word-break:break-all"><a href="'+$u+'">'+$u+'</a></p><p>Pas de compte ni de mot de passe. Internet requis.</p><p style="color:#667">Gardez cette fenetre et le PC allumes pendant la presentation.</p></body></html>'; Set-Content -Path 'QR_POUR_LES_ELEVES.html' -Value $html -Encoding UTF8; Start-Process 'QR_POUR_LES_ELEVES.html'"
echo.
echo IMPORTANT : ne fermez pas les fenetres du serveur et du tunnel.
echo Le PC doit rester allume et connecte a Internet.
echo Fermez les deux fenetres apres la presentation pour couper l'acces.
echo.
pause
