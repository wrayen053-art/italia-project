$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add("http://127.0.0.1:5500/")
try {
    $listener.Start()
    Write-Host "ITALIA est disponible localement sur http://127.0.0.1:5500/"
    Write-Host "Gardez cette fenetre ouverte pendant la presentation."
    while ($listener.IsListening) {
        $ctx = $listener.GetContext()
        try {
            $relative = [uri]::UnescapeDataString($ctx.Request.Url.AbsolutePath.TrimStart("/"))
            if ([string]::IsNullOrWhiteSpace($relative)) { $relative = "index.html" }
            $full = [System.IO.Path]::GetFullPath((Join-Path $root $relative))
            if (-not $full.StartsWith([System.IO.Path]::GetFullPath($root), [System.StringComparison]::OrdinalIgnoreCase)) {
                $ctx.Response.StatusCode = 403
                $ctx.Response.Close()
                continue
            }
            if (-not (Test-Path -LiteralPath $full -PathType Leaf)) {
                $ctx.Response.StatusCode = 404
                $ctx.Response.Close()
                continue
            }
            $ext = [System.IO.Path]::GetExtension($full).ToLowerInvariant()
            $mime = switch ($ext) {
                ".html" { "text/html; charset=utf-8" }
                ".css" { "text/css; charset=utf-8" }
                ".js" { "application/javascript; charset=utf-8" }
                ".json" { "application/json; charset=utf-8" }
                ".png" { "image/png" }
                ".jpg" { "image/jpeg" }
                ".jpeg" { "image/jpeg" }
                ".svg" { "image/svg+xml" }
                ".webp" { "image/webp" }
                ".ico" { "image/x-icon" }
                default { "application/octet-stream" }
            }
            $bytes = [System.IO.File]::ReadAllBytes($full)
            $ctx.Response.ContentType = $mime
            $ctx.Response.ContentLength64 = $bytes.Length
            $ctx.Response.Headers.Add("Cache-Control", "no-store")
            $ctx.Response.OutputStream.Write($bytes, 0, $bytes.Length)
            $ctx.Response.OutputStream.Close()
        } catch {
            try { $ctx.Response.StatusCode = 500; $ctx.Response.Close() } catch {}
        }
    }
} finally {
    if ($listener.IsListening) { $listener.Stop() }
    $listener.Close()
}
